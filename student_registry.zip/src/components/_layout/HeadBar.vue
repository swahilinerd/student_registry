<template>
    <nav class="navbar navbar-expand-lg navbar-light bg-primary">
        <div class="container-fluid">
            <a href="" class="navbar-brand p-3"></a>
        </div>
    </nav>
</template>

<script>
    export default {

    }
</script>