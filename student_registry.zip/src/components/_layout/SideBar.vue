<template>
    <div class="row">
        <div class="col-md-8 offset-2">
            <p>
                Welcome, Online Application System(OAS) is the platform  
                for online applicatio for all students who wish to apply at Mbeya University of
                science and techology.
            </p>

            <p>
                With this platform you will be able to 
                <ul>
                    <li>Apply for programmes</li>
                    <li>View your application results</li>
                </ul>
            </p>
            <p>
                For Inquiries Please,
                <ul>
                    <li>+255 692 142 862</li>
                    <li>+255 717 142 862</li>
                    <li>+255 768 142 862</li>
                </ul>
            </p>
            <p>
                <b>Note:</b>If you still dont have an account, You can register below
               
            </p>
        </div>
    </div>
</template>

<script>
    export default {

    }
</script>