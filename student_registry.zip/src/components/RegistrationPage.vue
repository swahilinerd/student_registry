<template>
    <div> 
        <HeadBar />
        <div class="row container mt-5">
            <div class="col-md-8">
                <SideBar />
            </div>
            <div class="col-md-4">
                <RegistrationForm />
            </div>
        </div>
        <FootBar />
    </div>
</template>


<script>
    export default {
        data() {
            return {
                
            }
        }
    }
</script>